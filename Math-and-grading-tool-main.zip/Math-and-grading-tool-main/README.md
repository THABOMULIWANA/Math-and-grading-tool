# Math-and-grading-tool
Tool used to find the roots of a quadratic equation and convert score ( 0- 100) to a letter grade.
